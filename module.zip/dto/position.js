const connection = require('../db-connection');


class Position {
    async addKey(){
        let sqlScript = ``;
        return connection.query(sqlScript);
    }

    async getAll(){

    }

    async getOne(){

    }

    async editKey(){

    }

    async
}

module.exports = new Position();