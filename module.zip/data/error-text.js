const error = {
    noData: 'Не все данные заполнены'
}

module.exports = error;