module.exports = {
    jwt: {
        accessSalt: "access",
        refreshSalt: 'refresh'
    },
    db: {
        host : "j45316134.myjino.ru",
        database : "j45316134",
        user : "j45316134",
        password : "cf}j}R75tRzM"
    }
}